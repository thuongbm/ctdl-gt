//Tichpx
#include<bits/stdc++.h>
using namespace std;

int main()
{
	cout<<sizeof(long long)<<"\n";
	cout<<sizeof(long )<<"\n";
	cout<<sizeof(int )<<"\n";
}

