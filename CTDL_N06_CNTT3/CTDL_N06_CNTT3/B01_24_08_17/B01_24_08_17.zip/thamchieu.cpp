//Tichpx
#include<bits/stdc++.h>
using namespace std;
void bp(int x,int &y)
{
	y=x*x;
}
int main()
{
	int a=7,b=5;
	bp(a,b);
	cout<<"a = "<<a<<"\n";
	cout<<"b = "<<b<<"\n";
}

