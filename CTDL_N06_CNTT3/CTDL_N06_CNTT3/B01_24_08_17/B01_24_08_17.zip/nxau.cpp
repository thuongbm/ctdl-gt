//Tichpx
#include<bits/stdc++.h>
using namespace std;

int main()
{
	string ten;
	//cin>>ten;
	getline(cin,ten);   //gets(ten)               scanf("%[^\n]",ten)
	cout<<"ten : "<<ten;
}

