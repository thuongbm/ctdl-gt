//Tichpx
#include<bits/stdc++.h>
using namespace std;

int main()
{
	long n;
	double x,y;
	string s;
	cout<<setw(10)<<setprecision(3)<<fixed;
	cin>>n>>x>>y>>s;
	cout<<"\nGia tri n "<<n;	
	cout<<"\nGia tri x "<<x;	
	cout<<"\nGia tri y "<<y;
	cout<<"\nXau ky tu "<<s;	
}

