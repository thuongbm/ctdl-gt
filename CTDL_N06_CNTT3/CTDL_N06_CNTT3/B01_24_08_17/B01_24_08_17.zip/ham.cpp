//Tichpx
#include<bits/stdc++.h>
using namespace std;

//int bp(int x)
//{
//	return x*x;
//}
double bp(double x)
{
	return x*x;
}

int main()
{
	cout<<bp(7)<<"\n";
	cout<<bp(7.0)<<"\n";
	
}

