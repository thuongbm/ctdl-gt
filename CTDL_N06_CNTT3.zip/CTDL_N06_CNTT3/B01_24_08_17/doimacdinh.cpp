//Tichpx
#include<bits/stdc++.h>
using namespace std;

int fun(int a=4,int b=6);
int main()
{
	cout<<fun(3,7)<<"\n";
	cout<<fun()<<"\n";
	cout<<fun(5)<<"\n";
}
int fun(int a,int b)
{
	return a*b;
}

